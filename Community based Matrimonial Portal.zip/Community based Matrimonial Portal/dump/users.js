[{
    "_id": {
        "$oid": "5e32e9da1c9d4400006f10a1"
    },
    "firstname": "Salman",
    "email": "salamkhan@gmail.com",
    "type": "User",
    "gender": "Male",
    "password": "123",
    "photourl": "https://upload.wikimedia.org/wikipedia/commons/8/81/Salman_Khan_filmfare.jpg",
    "isVerfied": true,
    "isActive": true,
    "personaldetails": {
        "$oid": "5e3f7834095fce45bc5cb143"
    },
    "recommendationdetails": {
        "$oid": "5e9930eb1c9d44000062f14b"
    }
}, {
    "_id": {
        "$oid": "5e573b831c9d440000fc9757"
    },
    "firstname": "Kareena",
    "email": "kareena@gmail.com",
    "type": "User",
    "gender": "Female",
    "password": "123",
    "photourl": "https://upload.wikimedia.org/wikipedia/commons/f/f8/Kareena_Kapoor_in_2018.jpg",
    "isVerfied": true,
    "isActive": true,
    "personaldetails": {
        "$oid": "5e573cda1c9d44000021252c"
    },
    "recommendationdetails": {
        "$oid": "5e99305b1c9d44000062f14a"
    }
}, {
    "_id": {
        "$oid": "5e573d4b1c9d44000021252d"
    },
    "firstname": "Akshay",
    "email": "akshay@gmail.com",
    "type": "User",
    "gender": "Male",
    "password": "123",
    "photourl": "https://www.gstatic.com/tv/thumb/persons/90028/90028_v9_ba.jpg",
    "isVerfied": true,
    "isActive": true,
    "personaldetails": {
        "$oid": "5e573d801c9d44000021252e"
    },
    "recommendationdetails": {
        "$oid": "5e933c6139fb7d0000c46fae"
    }
}, {
    "_id": {
        "$oid": "5e573e6b1c9d440000212532"
    },
    "firstname": "Deepika",
    "email": "deepika@gmail.com",
    "type": "User",
    "gender": "Female",
    "password": "123",
    "photourl": "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Deepika_Padukone_Cannes_2018_%28cropped%29.jpg/220px-Deepika_Padukone_Cannes_2018_%28cropped%29.jpg",
    "isVerfied": false,
    "isActive": false,
    "personaldetails": {
        "$oid": "5e573ed81c9d440000212533"
    },
    "recommendationdetails": {
        "$oid": "5e992f121c9d44000062f149"
    }
}, {
    "_id": {
        "$oid": "5e899676f218c33dea4ba9ea"
    },
    "isVerfied": true,
    "isActive": true,
    "firstname": "Hrithik",
    "email": "hrithikroshan@gmail.com",
    "type": "User",
    "gender": "Male",
    "password": "admincq",
    "photourl": "",
    "personaldetails": {
        "$oid": "5e899675f218c33dea4ba9e9"
    },
    "recommendationdetails": {
        "$oid": "5e992e4d1c9d44000062f148"
    }
}, {
    "_id": {
        "$oid": "5e89985ef218c33dea4ba9ec"
    },
    "isVerfied": true,
    "isActive": true,
    "firstname": "Parneeti",
    "email": "parneetichopra@gmail.com",
    "type": "User",
    "gender": "Female",
    "password": "admincq",
    "photourl": "https://www.gstatic.com/tv/thumb/persons/645076/645076_v9_ba.jpg",
    "personaldetails": {
        "$oid": "5e89985ef218c33dea4ba9eb"
    },
    "recommendationdetails": {
        "$oid": "5e992dd61c9d44000062f147"
    }
}, {
    "_id": {
        "$oid": "5e89fe115d375f4dc4a35657"
    },
    "firstname": "Kajal",
    "email": "Kajal@gmail.com",
    "type": "User",
    "gender": "Female",
    "password": "123",
    "photourl": "https://pbs.twimg.com/profile_images/727053878978449408/rHgoO6Za_400x400.jpg",
    "isVerfied": true,
    "isActive": true,
    "personaldetails": {
        "$oid": "5e89fe9a5d375f4dc4a35658"
    },
    "recommendationdetails": {
        "$oid": "5e992d751c9d44000062f146"
    }
}, {
    "_id": {
        "$oid": "5e89ff9b5d375f4dc4a35659"
    },
    "firstname": "Jacqueline",
    "email": "jacqueline@gmail.com",
    "type": "User",
    "gender": "Female",
    "password": "123",
    "photourl": "https://www.gstatic.com/tv/thumb/persons/657700/657700_v9_ba.jpg",
    "isVerfied": true,
    "isActive": true,
    "personaldetails": {
        "$oid": "5e8a001d5d375f4dc4a3565a"
    },
    "recommendationdetails": {
        "$oid": "5e9929951c9d44000062f145"
    }
}, {
    "_id": {
        "$oid": "5e8a01245d375f4dc4a3565b"
    },
    "firstname": "Taapsee",
    "email": "taapsee@gmail.com",
    "type": "User",
    "gender": "Female",
    "password": "123",
    "photourl": "https://pbs.twimg.com/profile_images/1146472490253742081/2wDg1l0D_400x400.jpg",
    "isVerfied": true,
    "isActive": true,
    "personaldetails": {
        "$oid": "5e8a01535d375f4dc4a3565c"
    },
    "recommendationdetails": {
        "$oid": "5e9929021c9d44000062f144"
    }
}]